/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./dist/*"],
  theme: {
    // fontFamily{
    //   'sans': ['jost'],
    //   'serif' : ['jost'],
    // },
    extend: {
    },
  },
  plugins: [],
}